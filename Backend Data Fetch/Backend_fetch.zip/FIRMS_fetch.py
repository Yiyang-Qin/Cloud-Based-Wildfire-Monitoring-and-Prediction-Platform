import requests
import pandas as pd

API_KEY = "094ea417efad2049cf4e04ee47ff4951"

# Use VIIRS, because it’s higher resolution than MODIS
collection = "viirs-snpp-c2"

# Bounding box for broader Los Angeles region (could expand slightly)
bbox = [-120.0, 32.5, -116.5, 35.0]  # (west, south, east, north)

# Fetch past 365 days
days = 10

# Construct the URL
url = f"https://firms.modaps.eosdis.nasa.gov/api/area/csv/{API_KEY}/{collection}/{bbox[0]},{bbox[1]},{bbox[2]},{bbox[3]}/{days}"

print("Fetching:", url)
response = requests.get(url)

if response.ok and "latitude" in response.text:
    with (open("la_fire_data_full_year.csv", "w") as f):
        f.write(response.text)
    print("✅ Fire data saved to 'la_fire_data_full_year.csv'")
    df = pd.read_csv("la_fire_data_full_year.csv")
    print(f"✅ Loaded {len(df)} fire detections.")
    print(df.head())
else:
    print("❌ Error fetching data:", response.text)
